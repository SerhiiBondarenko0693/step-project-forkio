# Step-cards

Vlad Mezheritskyi:
1) Class Visit and child classes
2) Drag and Drop
3) AJAX requests
4) Styles

Max Yevtushenko:
1) Class Form and child classes
2) Edit card with Put request
3) Styles

Yakovenko Andrey
1) Class Modal
2) Filter
3) Styles
4) AJAX request